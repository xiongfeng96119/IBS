CREATE VIEW v_menu AS
  SELECT
    `m`.`id`        AS `id`,
    `m`.`name`      AS `name`,
    `m`.`url`       AS `url`,
    `m`.`icon`      AS `icon`,
    `m`.`parent_id` AS `parent_id`,
    `m2`.`name`     AS `parentName`
  FROM (`ibs`.`menu` `m` LEFT JOIN `ibs`.`menu` `m2` ON ((`m`.`parent_id` = `m2`.`id`)));

